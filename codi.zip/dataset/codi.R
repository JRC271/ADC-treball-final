library("xlsx")
install.packages("devtools")
devtools::install_github("rstudio/EDAWR")

#Carreguem les dades (s'ha de canviar la carpeta en la qual est� el dataset guardat)

setwd("C:/users/usuario/Desktop/dataset")
data = read.csv("fullCOVIDtable.csv", header = T, sep = ";")
data <- data[!is.na(data$Cases),]
data <- data[!is.na(data$TEMPERATURE),]

#Agafem les dades pels 10 pa�sos seleccionats, que amb tots els pa�sos �s igual

Spain = data[data$COUNTRY == "Spain",]
View(Spain)

Spain_model1 <- lm(Spain$New.Cases ~ Spain$TEMPERATURE)
summary(Spain_model1)
Spain_model2 <- lm(Spain$New.Cases ~ Spain$HUMIDITY)
summary(Spain_model2)
Spain_model3 <- lm(Spain$New.Cases ~ Spain$WIND)
summary(Spain_model3)
Spain_model4 <- lm(Spain$New.Cases ~ Spain$TEMPERATURE + Spain$HUMIDITY + Spain$WIND)
summary(Spain_model4)
Spain_model5 <- lm(Spain$New.Cases ~ Spain$TEMPERATURE + Spain$HUMIDITY + Spain$WIND - 1) #Model general sense intercept.
summary(Spain_model5)

Spain_cases = Spain$Cases
Spain_new_cases = Spain$New.Cases
Spain_temperature = Spain$TEMPERATURE
Spain_humidity = Spain$HUMIDITY
Spain_wind = Spain$WIND

Argentina = data[data$COUNTRY == "Argentina",]

Argentina_model1 <- lm(Argentina$New.Cases ~ Argentina$TEMPERATURE)
summary(Argentina_model1)
Argentina_model2 <- lm(Argentina$New.Cases ~ Argentina$HUMIDITY)
summary(Argentina_model2)
Argentina_model3 <- lm(Argentina$New.Cases ~ Argentina$WIND)
summary(Argentina_model3)
Argentina_model4 <- lm(Argentina$New.Cases ~ Argentina$TEMPERATURE + Argentina$HUMIDITY + Argentina$WIND)
summary(Argentina_model4)
Argentina_model5 <- lm(Argentina$New.Cases ~ Argentina$TEMPERATURE + Argentina$HUMIDITY + Argentina$WIND - 1) #Model general sense intercept.
summary(Argentina_model5)

Argentina_cases = Argentina$Cases
Argentina_new_cases = Argentina$New.Cases
Argentina_temperature = Argentina$TEMPERATURE
Argentina_humidity = Argentina$HUMIDITY
Argentina_wind = Argentina$WIND

Czechia = data[data$COUNTRY == "Czechia",]

Czechia_model1 <- lm(Czechia$New.Cases ~ Czechia$TEMPERATURE)
summary(Czechia_model1)
Czechia_model2 <- lm(Czechia$New.Cases ~ Czechia$HUMIDITY)
summary(Czechia_model2)
Czechia_model3 <- lm(Czechia$New.Cases ~ Czechia$WIND)
summary(Czechia_model3)
Czechia_model4 <- lm(Czechia$New.Cases ~ Czechia$TEMPERATURE + Czechia$HUMIDITY + Czechia$WIND)
summary(Czechia_model4)
Czechia_model5 <- lm(Czechia$New.Cases ~ Czechia$TEMPERATURE + Czechia$HUMIDITY + Czechia$WIND - 1) #Model general sense intercept.
summary(Czechia_model5)

Czechia_cases = Czechia$Cases
Czechia_new_cases = Czechia$New.Cases
Czechia_temperature = Czechia$TEMPERATURE
Czechia_humidity = Czechia$HUMIDITY
Czechia_wind = Czechia$WIND

Germany = data[data$COUNTRY == "Germany",]

Germany_model1 <- lm(Germany$New.Cases ~ Germany$TEMPERATURE)
summary(Germany_model1)
Germany_model2 <- lm(Germany$New.Cases ~ Germany$HUMIDITY)
summary(Germany_model2)
Germany_model3 <- lm(Germany$New.Cases ~ Germany$WIND)
summary(Germany_model3)
Germany_model4 <- lm(Germany$New.Cases ~ Germany$TEMPERATURE + Germany$HUMIDITY + Germany$WIND)
summary(Germany_model4)
Germany_model5 <- lm(Germany$New.Cases ~ Germany$TEMPERATURE + Germany$HUMIDITY + Germany$WIND - 1) #Model general sense intercept.
summary(Germany_model5)

Germany_cases = Germany$Cases
Germany_new_cases = Germany$New.Cases
Germany_temperature = Germany$TEMPERATURE
Germany_humidity = Germany$HUMIDITY
Germany_wind = Germany$WIND

Mexico = data[data$COUNTRY == "Mexico",]

Mexico_model1 <- lm(Mexico$New.Cases ~ Mexico$TEMPERATURE)
summary(Mexico_model1)
Mexico_model2 <- lm(Mexico$New.Cases ~ Mexico$HUMIDITY)
summary(Mexico_model2)
Mexico_model3 <- lm(Mexico$New.Cases ~ Mexico$WIND)
summary(Mexico_model3)
Mexico_model4 <- lm(Mexico$New.Cases ~ Mexico$TEMPERATURE + Mexico$HUMIDITY + Mexico$WIND)
summary(Mexico_model4)
Mexico_model5 <- lm(Mexico$New.Cases ~ Mexico$TEMPERATURE + Mexico$HUMIDITY + Mexico$WIND - 1) #Model general sense intercept.
summary(Mexico_model5)

Mexico_cases = Mexico$Cases
Mexico_new_cases = Mexico$New.Cases
Mexico_temperature = Mexico$TEMPERATURE
Mexico_humidity = Mexico$HUMIDITY
Mexico_wind = Mexico$WIND

Japan = data[data$COUNTRY == "Japan",]

Japan_model1 <- lm(Japan$New.Cases ~ Japan$TEMPERATURE)
summary(Japan_model1)
Japan_model2 <- lm(Japan$New.Cases ~ Japan$HUMIDITY)
summary(Japan_model2)
Japan_model3 <- lm(Japan$New.Cases ~ Japan$WIND)
summary(Japan_model3)
Japan_model4 <- lm(Japan$New.Cases ~ Japan$TEMPERATURE + Japan$HUMIDITY + Japan$WIND)
summary(Japan_model4)
Japan_model5 <- lm(Japan$New.Cases ~ Japan$TEMPERATURE + Japan$HUMIDITY + Japan$WIND - 1) #Model general sense intercept.
summary(Japan_model5)

Japan_cases = Japan$Cases
Japan_new_cases = Japan$New.Cases
Japan_temperature = Japan$TEMPERATURE
Japan_humidity = Japan$HUMIDITY
Japan_wind = Japan$WIND

Australia = data[data$COUNTRY == "Australia",]

Australia_model1 <- lm(Australia$New.Cases ~ Australia$TEMPERATURE)
summary(Australia_model1)
Australia_model2 <- lm(Australia$New.Cases ~ Australia$HUMIDITY)
summary(Australia_model2)
Australia_model3 <- lm(Australia$New.Cases ~ Australia$WIND)
summary(Australia_model3)
Australia_model4 <- lm(Australia$New.Cases ~ Australia$TEMPERATURE + Australia$HUMIDITY + Australia$WIND)
summary(Australia_model4)
Australia_model5 <- lm(Australia$New.Cases ~ Australia$TEMPERATURE + Australia$HUMIDITY + Australia$WIND - 1) #Model general sense intercept.
summary(Australia_model5)

Australia_cases = Australia$Cases
Australia_new_cases = Australia$New.Cases
Australia_temperature = Australia$TEMPERATURE
Australia_humidity = Australia$HUMIDITY
Australia_wind = Australia$WIND

Iran = data[data$COUNTRY == "Iran",]

Iran_model1 <- lm(Iran$New.Cases ~ Iran$TEMPERATURE)
summary(Iran_model1)
Iran_model2 <- lm(Iran$New.Cases ~ Iran$HUMIDITY)
summary(Iran_model2)
Iran_model3 <- lm(Iran$New.Cases ~ Iran$WIND)
summary(Iran_model3)
Iran_model4 <- lm(Iran$New.Cases ~ Iran$TEMPERATURE + Iran$HUMIDITY + Iran$WIND)
summary(Iran_model4)
Iran_model5 <- lm(Iran$New.Cases ~ Iran$TEMPERATURE + Iran$HUMIDITY + Iran$WIND - 1)
summary(Iran_model5)

Iran_cases = Iran$Cases
Iran_new_cases = Iran$New.Cases
Iran_temperature = Iran$TEMPERATURE
Iran_humidity = Iran$HUMIDITY
Iran_wind = Iran$WIND

Madagascar = data[data$COUNTRY == "Madagascar",]

Madagascar_model1 <- lm(Madagascar$New.Cases ~ Madagascar$TEMPERATURE)
summary(Madagascar_model1)
Madagascar_model2 <- lm(Madagascar$New.Cases ~ Madagascar$HUMIDITY)
summary(Madagascar_model2)
Madagascar_model3 <- lm(Madagascar$New.Cases ~ Madagascar$WIND)
summary(Madagascar_model3)
Madagascar_model4 <- lm(Madagascar$New.Cases ~ Madagascar$TEMPERATURE + Madagascar$HUMIDITY + Madagascar$WIND)
summary(Madagascar_model4)
Madagascar_model5 <- lm(Madagascar$New.Cases ~ Madagascar$TEMPERATURE + Madagascar$HUMIDITY + Madagascar$WIND - 1) #Model general sense intercept.
summary(Madagascar_model5)

Madagascar_cases = Madagascar$Cases
Madagascar_new_cases = Madagascar$New.Cases
Madagascar_temperature = Madagascar$TEMPERATURE
Madagascar_humidity = Madagascar$HUMIDITY
Madagascar_wind = Madagascar$WIND

Afghanistan <- data[data$COUNTRY == "Afghanistan",]

Afghanistan_model1 <- lm(Afghanistan$New.Cases ~ Afghanistan$TEMPERATURE)
summary(Afghanistan_model1)
Afghanistan_model2 <- lm(Afghanistan$New.Cases ~ Afghanistan$HUMIDITY)
summary(Afghanistan_model2)
Afghanistan_model3 <- lm(Afghanistan$New.Cases ~ Afghanistan$WIND)
summary(Afghanistan_model3)
Afghanistan_model4 <- lm(Afghanistan$New.Cases ~ Afghanistan$TEMPERATURE + Afghanistan$HUMIDITY + Afghanistan$WIND)
summary(Afghanistan_model4)
Afghanistan_model5 <- lm(Afghanistan$New.Cases ~ Afghanistan$TEMPERATURE + Afghanistan$HUMIDITY + Afghanistan$WIND - 1) #Model general sense intercept.
summary(Afghanistan_model5)

Afghanistan_cases = Afghanistan$Cases
Afghanistan_new_cases = Afghanistan$New.Cases
Afghanistan_temperature = Afghanistan$TEMPERATURE
Afghanistan_humidity = Afghanistan$HUMIDITY
Afghanistan_wind = Afghanistan$WIND

par("mar")

par(mfrow=c(5,2),mar=c(1,1,1,1),mgp=c(5,1,0),oma=c(2, 2, 2, 2))
Spain_plot = plot(Spain_new_cases,Spain_temperature)
title("Espanya", line = -1, adj = 0.75)
Argentina_plot = plot(Argentina_new_cases,Argentina_temperature)
title("Argentina", line = -6,adj = 0.75)
Czechia_plot = plot(Czechia_new_cases,Czechia_temperature)
title("Tx�quia", line = -1)
Germany_plot = plot(Germany_new_cases,Germany_temperature)
title("Alemanya", line = -1)
Mexico_plot = plot(Mexico_new_cases,Mexico_temperature)
title("M�xic", line = -1, adj = 0.65)
Japan_plot = plot(Japan_new_cases,Japan_temperature)
title("Jap�", line = -7, adj = 0.75)
Australia_plot = plot(Australia_new_cases,Australia_temperature)
title("Austr�lia",line=-1)
Iran_plot = plot(Iran_new_cases,Iran_temperature)
title("Iran",line = -1)
Madagascar_plot = plot(Madagascar_new_cases,Madagascar_temperature)
title("Madagascar",line = -7)
Afghanistan_plot = plot(Afghanistan_new_cases,Afghanistan_temperature)
title("Afganistan",line=-7,adj=0.7)

Spain_interesting_data <- data.frame(Spain_new_cases,Spain_temperature)
Argentina_interesting_data <- data.frame(Argentina_new_cases,Argentina_temperature)

cor(Spain_new_cases, Spain_temperature, method=c("pearson"))
cor(Argentina_new_cases,Argentina_temperature,method=c("pearson"))
cor(Czechia_new_cases,Czechia_temperature,method=c("pearson"))
cor(Germany_new_cases,Germany_temperature,method=c("pearson"))
cor(Mexico_new_cases,Mexico_temperature,method=c("pearson"))
cor(Japan_new_cases,Japan_temperature,method=c("pearson"))
cor(Australia_new_cases,Australia_temperature,method=c("pearson"))
cor(Iran_new_cases,Iran_temperature,method=c("pearson"))
cor(Madagascar_new_cases,Madagascar_temperature,method=c("pearson")) 
cor(Afghanistan_new_cases,Afghanistan_temperature,method=c("pearson"))

cor(Spain_new_cases, Spain_temperature, method=c("spearman"))
cor(Argentina_new_cases,Argentina_temperature,method=c("spearman"))
cor(Czechia_new_cases,Czechia_temperature,method=c("spearman"))
cor(Germany_new_cases,Germany_temperature,method=c("spearman"))
cor(Mexico_new_cases,Mexico_temperature,method=c("spearman"))
cor(Japan_new_cases,Japan_temperature,method=c("spearman"))
cor(Australia_new_cases,Australia_temperature,method=c("spearman"))
cor(Iran_new_cases,Iran_temperature,method=c("spearman")) 
cor(Madagascar_new_cases,Madagascar_temperature,method=c("spearman")) 
cor(Afghanistan_new_cases,Afghanistan_temperature,method=c("spearman"))


cor(Spain_new_cases, Spain_humidity, method=c("pearson"))
cor(Argentina_new_cases,Argentina_humidity,method=c("pearson"))
cor(Czechia_new_cases,Czechia_humidity,method=c("pearson"))
cor(Germany_new_cases,Germany_humidity,method=c("pearson"))
cor(Mexico_new_cases,Mexico_humidity,method=c("pearson"))
cor(Japan_new_cases,Japan_humidity,method=c("pearson"))
cor(Australia_new_cases,Australia_humidity,method=c("pearson"))
cor(Iran_new_cases,Iran_humidity,method=c("pearson")) 
cor(Madagascar_new_cases,Madagascar_humidity,method=c("pearson")) 
cor(Afghanistan_new_cases,Afghanistan_humidity,method=c("pearson"))

cor(Spain_new_cases, Spain_humidity, method=c("spearman"))
cor(Argentina_new_cases,Argentina_humidity,method=c("spearman"))
cor(Czechia_new_cases,Czechia_humidity,method=c("spearman"))
cor(Germany_new_cases,Germany_humidity,method=c("spearman"))
cor(Mexico_new_cases,Mexico_humidity,method=c("spearman"))
cor(Japan_new_cases,Japan_humidity,method=c("spearman"))
cor(Australia_new_cases,Australia_humidity,method=c("spearman"))
cor(Iran_new_cases,Iran_humidity,method=c("spearman")) 
cor(Madagascar_new_cases,Madagascar_humidity,method=c("spearman")) 
cor(Afghanistan_new_cases,Afghanistan_humidity,method=c("spearman"))


cor(Spain_new_cases, Spain_wind, method=c("pearson"))
cor(Argentina_new_cases,Argentina_wind,method=c("pearson"))
cor(Czechia_new_cases,Czechia_wind,method=c("pearson"))
cor(Germany_new_cases,Germany_wind,method=c("pearson"))
cor(Mexico_new_cases,Mexico_wind,method=c("pearson"))
cor(Japan_new_cases,Japan_wind,method=c("pearson"))
cor(Australia_new_cases,Australia_wind,method=c("pearson"))
cor(Iran_new_cases,Iran_wind,method=c("pearson")) 
cor(Madagascar_new_cases,Madagascar_wind,method=c("pearson")) 
cor(Afghanistan_new_cases,Afghanistan_wind,method=c("pearson"))

cor(Spain_new_cases, Spain_wind, method=c("spearman"))
cor(Argentina_new_cases,Argentina_wind,method=c("spearman"))
cor(Czechia_new_cases,Czechia_wind,method=c("spearman"))
cor(Germany_new_cases,Germany_wind,method=c("spearman"))
cor(Mexico_new_cases,Mexico_wind,method=c("spearman"))
cor(Japan_new_cases,Japan_wind,method=c("spearman"))
cor(Australia_new_cases,Australia_wind,method=c("spearman"))
cor(Iran_new_cases,Iran_wind,method=c("spearman")) 
cor(Madagascar_new_cases,Madagascar_wind,method=c("spearman")) 
cor(Afghanistan_new_cases,Afghanistan_wind,method=c("spearman"))

#Tests permutacionals

#SPAIN

par(mfrow=c(1,3),mar=c(1,1,1,1),mgp=c(5,1,0),oma=c(2, 2, 2, 2))

x= Spain_new_cases
y= Spain_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y,use ="complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st,main="Temperatura Espanya")

x= Spain_new_cases
y= Spain_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample (y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Espanya")

x= Spain_new_cases
y= Spain_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample (y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st,main="Vent Espanya")

#ARGENTINA

x= Argentina_new_cases
y= Argentina_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
class(st)
hist(st,main="Temperatura Argentina")

x= Argentina_new_cases
y= Argentina_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st,main="Humitat Argentina")

x= Argentina_new_cases
y= Argentina_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st,main="Vent Argentina")

#CZECHIA

x= Czechia_new_cases
y= Czechia_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Tx�quia")

x= Czechia_new_cases
y= Czechia_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Tx�quia")

x= Czechia_new_cases
y= Czechia_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Tx�quia")

#GERMANY

x= Germany_new_cases
y= Germany_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Alemanya")

x= Germany_new_cases
y= Germany_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Alemanya")

x= Germany_new_cases
y= Germany_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Alemanya")

#MEXICO

x= Mexico_new_cases
y= Mexico_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura M�xic")

x= Mexico_new_cases
y= Mexico_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat M�xic")

x= Mexico_new_cases
y= Mexico_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent M�xic")

#JAPAN

x= Japan_new_cases
y= Japan_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Jap�")

x= Japan_new_cases
y= Japan_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Jap�")

x= Japan_new_cases
y= Japan_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Jap�")

#AUSTRALIA

x= Australia_new_cases
y= Australia_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Austr�lia")

x= Australia_new_cases
y= Australia_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Austr�lia")

x= Australia_new_cases
y= Australia_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Austr�lia")

#IRAN

x= Iran_new_cases
y= Iran_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Iran")

x= Iran_new_cases
y= Iran_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Iran")

x= Iran_new_cases
y= Iran_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Iran")

#MADAGASCAR

x= Madagascar_new_cases
y= Madagascar_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Madagascar")

x= Madagascar_new_cases
y= Madagascar_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Humitat Madagascar")

x= Madagascar_new_cases
y= Madagascar_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Madagascar")

#AFGHANISTAN

x= Afghanistan_new_cases
y= Afghanistan_temperature
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x,use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Temperatura Afganistan")

x= Afghanistan_new_cases
y= Afghanistan_humidity
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st,main = "Humitat Afganistan")

x= Afghanistan_new_cases
y= Afghanistan_wind
nr=10000 #number of rearrangements to be examined
st=numeric(nr)
sttrue= cor(x,y, use = "complete.obs")
print(sttrue)
n=length(y)
cnt=0
for (i in 1:nr){
  d= sample(y,n)
  st[i]<-cor(d,x, use = "complete.obs")
  if (st[i] > sttrue)cnt=cnt+1 }
cnt/nr #pvalue
hist(st, main = "Vent Afganistan")

#Bootstrap

par(mfrow=c(3,2),mar=c(1,1,1,1),mgp=c(5,1,0),oma=c(2, 2, 2, 2))

a <- lm(Spain$New.Cases ~ Spain$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Spain$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Spain$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Spain$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Spain$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Spain$New.Cases ~ Spain$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Spain$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Spain$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Spain$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Spain$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Spain$New.Cases ~ Spain$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Spain$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Spain$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Spain$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Spain$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#ARGENTINA

a <- lm(Argentina$New.Cases ~ Argentina$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Argentina$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Argentina$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Argentina$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Argentina$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Argentina$New.Cases ~ Argentina$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Argentina$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Argentina$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Argentina$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Argentina$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Argentina$New.Cases ~ Argentina$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Argentina$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Argentina$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Argentina$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Argentina$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#CZECHIA

a <- lm(Czechia$New.Cases ~ Czechia$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Czechia$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Czechia$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Czechia$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Czechia$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Czechia$New.Cases ~ Czechia$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Czechia$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Czechia$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Czechia$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Czechia$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Czechia$New.Cases ~ Czechia$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Czechia$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Czechia$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Czechia$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Czechia$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#GERMANY

a <- lm(Germany$New.Cases ~ Germany$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Germany$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Germany$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Germany$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Germany$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Germany$New.Cases ~ Germany$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Germany$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Germany$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Germany$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Germany$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Germany$New.Cases ~ Germany$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Germany$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Germany$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Germany$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Germany$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#MEXICO

a <- lm(Mexico$New.Cases ~ Mexico$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Mexico$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Mexico$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Mexico$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Mexico$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Mexico$New.Cases ~ Mexico$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Mexico$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Mexico$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Mexico$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Mexico$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Mexico$New.Cases ~ Mexico$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Mexico$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Mexico$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Mexico$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Mexico$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#JAPAN

a <- lm(Japan$New.Cases ~ Japan$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Japan$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Japan$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Japan$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Japan$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Japan$New.Cases ~ Japan$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Japan$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Japan$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Japan$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Japan$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Japan$New.Cases ~ Japan$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Japan$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Japan$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Japan$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Japan$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#AUSTRALIA

a <- lm(Australia$New.Cases ~ Australia$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Australia$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Australia$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Australia$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Australia$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Australia$New.Cases ~ Australia$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Australia$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Australia$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Australia$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Australia$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Australia$New.Cases ~ Australia$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Australia$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Australia$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Australia$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Australia$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#IRAN

a <- lm(Iran$New.Cases ~ Iran$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Iran$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Iran$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Iran$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Iran$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Iran$New.Cases ~ Iran$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Iran$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Iran$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Iran$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Iran$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Iran$New.Cases ~ Iran$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Iran$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Iran$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Iran$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Iran$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#MADAGASCAR

a <- lm(Madagascar$New.Cases ~ Madagascar$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Madagascar$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Madagascar$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Madagascar$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Madagascar$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Madagascar$New.Cases ~ Madagascar$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Madagascar$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Madagascar$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Madagascar$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Madagascar$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Madagascar$New.Cases ~ Madagascar$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Madagascar$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Madagascar$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Madagascar$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Madagascar$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

#AFGHANISTAN

a <- lm(Afghanistan$New.Cases ~ Afghanistan$TEMPERATURE)
b <- summary(a)
b

nsim <- 1000; n <- length(Afghanistan$TEMPERATURE)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Afghanistan$TEMPERATURE*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Afghanistan$TEMPERATURE)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Afghanistan$TEMPERATURE)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)


a <- lm(Afghanistan$New.Cases ~ Afghanistan$HUMIDITY)
b <- summary(a)
b

nsim <- 1000; n <- length(Afghanistan$HUMIDITY)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Afghanistan$HUMIDITY*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Afghanistan$HUMIDITY)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Afghanistan$HUMIDITY)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)

a <- lm(Afghanistan$New.Cases ~ Afghanistan$WIND)
b <- summary(a)
b

nsim <- 1000; n <- length(Afghanistan$WIND)
slope <- numeric(nsim); interc <- numeric(nsim)
r<- numeric(nsim); rcases <- numeric(n)
for (i in 1:nsim){
  error <- rnorm(n,0,b$sigma)
  rcases <- a$coefficients[1]+Afghanistan$WIND*a$coefficients[2]+error
  #print(rcases)
  c <- lm(rcases~Afghanistan$WIND)
  slope[i] <- c$coefficient[2]; interc[i] <- c$coefficient[1]
  r[i] <- cor(rcases,Afghanistan$WIND)
}

quantile(slope, probs = c(0.025,0.975))
quantile(r,probs = c(0.025,0.975))
hist(r,main=NULL)
boxplot(r)








